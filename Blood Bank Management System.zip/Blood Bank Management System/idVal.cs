﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blood_Bank
{
    public class idVal
    {
        public static int id { get; set; }
        public idVal(int i)
        {
            id = i;
        }
    }
}
